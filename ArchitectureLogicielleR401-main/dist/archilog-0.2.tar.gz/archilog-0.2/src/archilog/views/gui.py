from flask import Blueprint, render_template, request, redirect, url_for, send_file
import io
import archilog.models as models
import archilog.services as services
from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, IntegerField, validators

web_ui = Blueprint("web_ui", __name__)

class EntryForm(FlaskForm):
    name = StringField('Name', validators=[validators.DataRequired()])
    montant = FloatField('Montant', validators=[validators.DataRequired()])
    category = StringField('Category', validators=[validators.DataRequired()])

@web_ui.route("/home")
def home():
    entries = models.get_all_entries()
    return render_template("home.html", entries=entries)

@web_ui.route("/update/<uuid:id>", methods=["GET", "POST"])
def update_entry(id):
    entry = models.get_entry(id)
    form = EntryForm(obj=entry)

    if form.validate_on_submit():
        form.populate_obj(entry)
        models.update_entry(id, entry.name, entry.montant, entry.category)
        return redirect(url_for("web_ui.home"))

    return render_template("update.html", form=form, entry=entry)

@web_ui.route("/delete/<uuid:id>")
def delete_entry(id):
    models.delete_entry(id)
    return redirect(url_for("web_ui.home"))

@web_ui.route("/create_entry", methods=["GET", "POST"])
def create_entry():
    form = EntryForm()
    if form.validate_on_submit():
        models.create_entry(form.name.data, form.montant.data, form.category.data)
        return redirect(url_for("web_ui.home"))

    return render_template("create.html", form=form)

@web_ui.route("/export_csv")
def export_csv():
    csv_stringio = services.export_to_csv()
    csv_string = csv_stringio.getvalue()

    csv_bytes = io.BytesIO()
    csv_bytes.write(csv_string.encode("utf-8"))
    csv_bytes.seek(0)

    return send_file(
        csv_bytes,
        mimetype="text/csv",
        as_attachment=True,
        download_name="fichier_entree.csv"
    )

@web_ui.route("/import_csv", methods=["GET", "POST"])
def import_csv():
    if request.method == "POST":
        fichier = request.files.get("file")
        if not fichier:
            return "Importation ratée !"
        file_stream = io.TextIOWrapper(fichier.stream, encoding="utf-8")
        services.import_from_csv(file_stream)
        return redirect(url_for("web_ui.home"))

    return render_template("import_csv.html")
