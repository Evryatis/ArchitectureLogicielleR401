from flask import Flask
from archilog.views.gui import web_ui

def create_app():
    app = Flask(__name__)
    app.register_blueprint(web_ui)
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
